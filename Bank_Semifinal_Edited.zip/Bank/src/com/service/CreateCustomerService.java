package com.service;

import com.bean.Customer;
import com.dao.CreateCustomerDAO;



public class CreateCustomerService {
	public static String[] addNewCustomer(Customer c){
		return  new CreateCustomerDAO().addCustomerToDatabase(c);
	}
}
