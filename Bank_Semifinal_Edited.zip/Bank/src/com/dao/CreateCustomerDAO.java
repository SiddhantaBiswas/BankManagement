package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.Customer;
import com.util.DbTransaction;

public class CreateCustomerDAO {
	public String[] addCustomerToDatabase(Customer c){
		String[] output=new String[2];
		ResultSet rs;
		Connection con=DbTransaction.getConnection();

		//search with ssn if exist alreddy
		try {
			PreparedStatement checkIfExist=con.prepareStatement("select * from CUSTOMER_STATUS where SSN_ID=?");
			checkIfExist.setInt(1, c.getCustomerSSNId());
			rs=checkIfExist.executeQuery();
			//to_char(custom_seq.nextval,'FM0000001')
			
			//if not exist
			if(!rs.next()){
				System.out.println("point 3");
				PreparedStatement newEntry=con.prepareStatement("insert into CUSTOMER_STATUS values('cus'||LPAD(to_char(custom_seq.nextval),'6','0'),?,?,?,?,?,?,'account created on '||to_char(CURRENT_TIMESTAMP),'ACTIVE',CURRENT_TIMESTAMP)");
				newEntry.setInt(1, c.getCustomerSSNId());
				newEntry.setString(2, c.getCustomerName());
				newEntry.setInt(3,c.getAge());
				newEntry.setString(4, c.getAddress());
				newEntry.setString(5, c.getCity());
				newEntry.setString(6, c.getState());
				
				newEntry.executeUpdate();
				
				PreparedStatement getCustId=con.prepareStatement("select CUST_ID from CUSTOMER_STATUS where SSN_ID=?");
				getCustId.setInt(1, c.getCustomerSSNId());
				rs=getCustId.executeQuery();
				rs.next();
				output[0]=rs.getString(1);
				output[1]="new";
				return output;
				}
			//if exist
			else{
				//System.out.println("point 4");
				PreparedStatement checkIfDuplicate=con.prepareStatement("select CUST_ID ,STATUS from CUSTOMER_STATUS where SSN_ID=?");
				checkIfDuplicate.setInt(1, c.getCustomerSSNId());
				rs=checkIfDuplicate.executeQuery();
				rs.next();
				String status=rs.getString(2);
				//System.out.println("point 2"+status);
				//if active
				if(status.equalsIgnoreCase("active")){
					output[0]=rs.getString(1);
					output[1]="duplicate";
					return output;
				}
				else{
					PreparedStatement makeActive=con.prepareStatement("update CUSTOMER_STATUS set STATUS='ACTIVE' where SSN_ID=?");
					makeActive.setInt(1, c.getCustomerSSNId());
					makeActive.executeUpdate();
					PreparedStatement makeAccountActive=con.prepareStatement("update Account_STATUS set STATUS='ACTIVE' where ACCOUNT_ID=?");
					makeAccountActive.setString(1,rs.getString(1));
					makeAccountActive.executeUpdate();
					output[0]=rs.getString(1);
					output[1]="old";
					return output;
				}
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			DbTransaction.closeConnection(con);
		}
		
		
		
		
		
		return output;
	}
}

