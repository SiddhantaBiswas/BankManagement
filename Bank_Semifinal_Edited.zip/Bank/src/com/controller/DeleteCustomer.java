package com.controller;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Customer;
import com.service.DeleteCustomerService;


@WebServlet("/DeleteCustomer")
public class DeleteCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteCustomer() {
        super();
    }
protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException
{
	try {
		String id=req.getParameter("id");
		System.out.println(id);
		DeleteCustomerService b=new DeleteCustomerService();
		b.accountdelete(id);

		int i=b.deleteCustomer(id);
		
		if(i==1)
		{
			b.updateTime(id);
			RequestDispatcher rd=req.getRequestDispatcher("success.jsp");
			rd.forward(req, res);
;		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("not found.jsp");
			rd.forward(req, res);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}
	
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		String id=request.getParameter("Customer_Id");
		
		
		DeleteCustomerService b=new DeleteCustomerService();
		String a=b.validateCustomer(id);
		if(a.equalsIgnoreCase("ACTIVE"))
		{
		Customer c=b.viewCustomer(id);
		if(c==null)
		{
			
			RequestDispatcher rd=request.getRequestDispatcher("notfound.jsp");
			rd.forward(request,response);
		}
		else
		{
			request.setAttribute("customer",c);
			RequestDispatcher rd=request.getRequestDispatcher("Executive/DeleteCustomer.jsp");
			rd.forward(request,response);
		}
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("notfound.jsp");
			rd.forward(request,response);
		}
		
		
	}

}
