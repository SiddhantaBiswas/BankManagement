package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Account;
import com.service.AccountSearchService;
@WebServlet("/AccountSearchDropdown")
public class AccountSearchDropdown extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AccountSearchDropdown() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
   		String fla=request.getParameter("flag");
		//String s1 = (String)request.get("source");
        int flag=Integer.parseInt(fla);
              AccountSearchService s=new AccountSearchService();

               if(flag==1){
		            String custid=request.getParameter("custid");  
		            String type=request.getParameter("type");
		            
	    	        ArrayList<Account> account=s.search_AccountByIdService(custid,flag,type);//used to get data in form of arraylist
	    	        if(!account.isEmpty()){
		    	   //passing control to the jsp page by using requestDispatcher
		            	
			              request.setAttribute("message",account);
			              RequestDispatcher reqDisp = request.getRequestDispatcher("Cashier/SearchAccountView.jsp");
			              reqDisp.forward(request, response);
			         }
		            else{
			             String message="Invalid value Please re-enter your id";
				         request.setAttribute("message",message);
				         RequestDispatcher reqDisp = request.getRequestDispatcher("Cashier/Failed.jsp");
				         reqDisp.forward(request, response);
			         
		             }
                  }
	             else if(flag==2){         	
	        	     String accid=request.getParameter("accid");
	        	     String type=request.getParameter("type");
		             ArrayList<Account> account=s.search_AccountByIdService(accid,flag,type);//used to get data in form of arraylist
		             if(!account.isEmpty()){
		        	       //passing control to the jsp page by using requestDispatcher
			                request.setAttribute("message",account);
			                RequestDispatcher reqDisp = request.getRequestDispatcher("Cashier/SearchAccountView.jsp");
			                reqDisp.forward(request, response);
				      }
		              else{
		        	        String message="Invalid value Please re-enter your id";
					        request.setAttribute("message",message);
					        RequestDispatcher reqDisp = request.getRequestDispatcher("Cashier/Failed.jsp");
					        reqDisp.forward(request, response);

		               }
                  }

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String custid=request.getParameter("custid");
		String accid=request.getParameter("accid");
		int flag=0;
		AccountSearchService s=new AccountSearchService();
	    if(!custid.isEmpty()){
		  
			       flag=1;
			       String rs[]=s.search_AccountByIdService(flag,custid);//used to get data in form of arraylist
			       if(rs[0]!=null){
			    	   //passing control to the jsp page by using requestDispatcher
				      request.setAttribute("message",rs);
				      request.setAttribute("custid",custid);
				      request.setAttribute("flag",flag);
				      RequestDispatcher rd = request.getRequestDispatcher("Cashier/SearchAccountDropdown.jsp");
				    

				      rd.forward(request, response);
			       }
			      else{
				         String message="Invalid value Please re-enter your id";
					      request.setAttribute("message",message);
					      RequestDispatcher reqDisp = request.getRequestDispatcher("Cashier/Failed.jsp");
					      reqDisp.forward(request, response);
				         
			      }
	    }
		else if(!accid.isEmpty()){
	         	flag=2;

			           String[] rs=s.search_AccountByIdService(flag,accid);//used to get data in form of arraylist
			           if(rs[0]!=null){
			        	 //passing control to the jsp page by using requestDispatcher
				                request.setAttribute("message",rs);
							      request.setAttribute("accid",accid);
							      request.setAttribute("flag",flag);
				                RequestDispatcher reqDisp = request.getRequestDispatcher("Cashier/SearchAccountDropdown.jsp");
				                reqDisp.forward(request, response);

			           }
			           else{
			        	   String message="Invalid value Please re-enter your id";
						      request.setAttribute("message",message);
						      RequestDispatcher reqDisp = request.getRequestDispatcher("Cashier/Failed.jsp");
						      reqDisp.forward(request, response);

			           }
	   }
	
	}

}
