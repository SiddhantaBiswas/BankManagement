package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Customer;
import com.service.CreateCustomerService;



/**
 * Servlet implementation class CreateCustomerController
 */
@WebServlet("/CreateCustomerController")
public class CreateCustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateCustomerController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int customerSSNId=Integer.parseInt(request.getParameter("CustomerSSNId"));
		String customerName=request.getParameter("CustomerName");
		int age=Integer.parseInt(request.getParameter("Age"));
		String address=request.getParameter("Address");
		String state=request.getParameter("State");
		String city=request.getParameter("City");
		Customer newCustomer=new Customer();
		newCustomer.setCustomerSSNId(customerSSNId);
		newCustomer.setAddress(address);
		newCustomer.setAge(age);
		newCustomer.setCity(city);
		newCustomer.setCustomerName(customerName);
		newCustomer.setState(state);
		String[] output=CreateCustomerService.addNewCustomer(newCustomer);
		if(output!=null){
			if(output[1].equalsIgnoreCase("new"))
				request.setAttribute("message", "New customer added successfully! \n Your Customer ID is "+ output[0] +". \t\t\t\tThankYou!");
			else if(output[1].equalsIgnoreCase("duplicate"))
				request.setAttribute("message", "This customer already exists and the ID is "+ output[0]);
			else if(output[1].equalsIgnoreCase("old"))
				request.setAttribute("message", "The account is now reactivated. Your account number is: "+output[0]); 
			request.getRequestDispatcher("Executive/Success.jsp").forward(request, response);
		}
	}
}

