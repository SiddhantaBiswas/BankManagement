package com.service;

import java.util.TreeSet;

import com.bean.Account;
import com.dao.AccountStatusDAO;



public class AccountStatusService {

	public static TreeSet<Account> SearchAllAccount(){
		AccountStatusDAO dao=new AccountStatusDAO();
		TreeSet<Account> tree=new TreeSet<Account>();

		tree=dao.viewAllAccount();
		return tree;
	}




}
