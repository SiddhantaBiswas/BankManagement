package com.service;

import java.util.ArrayList;

import com.dao.DeleteCustomerDao;
import com.bean.*;

public class DeleteCustomerService 

{
  public Customer viewCustomer(String id)
  {
	  
	  
	  DeleteCustomerDao dao=new DeleteCustomerDao();
	  Customer b=dao.viewCustomerdao(id);
	  return b;
  }
  public int deleteCustomer(String id)
  {
	  DeleteCustomerDao dao=new DeleteCustomerDao();
	  int i=dao.deleteCustomerdao(id);
	  return i;
  }
public int accountdelete(String id) {
	
	DeleteCustomerDao dao=new DeleteCustomerDao();
	int j=dao.accountdeletedao(id);
	return j;
}
public void updateTime(String id) {
	DeleteCustomerDao dao=new DeleteCustomerDao();
	dao.updateTimeDao(id);
	
	
}
public String validateCustomer(String id) {
	// TODO Auto-generated method stub
	DeleteCustomerDao b=new DeleteCustomerDao();
	String c=b.validateCustomerDao(id);
	return c;
}
}
