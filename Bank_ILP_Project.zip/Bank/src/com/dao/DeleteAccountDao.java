package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;

import com.bean.Account;
import com.util.DbTransaction;

public class DeleteAccountDao {
	ResultSet rs=null;
	
	public ArrayList<Account> viewAccountsDao(String b2)
	{
		ArrayList<Account> list=new ArrayList<Account>();

		
		
		
		
		//Get connection object from DbTransaction object
		Connection con=DbTransaction.getConnection();
		//selecting account id's for particular customerid
		
		String sql="select * from ACCOUNT_STATUS where CUST_ID=? and status='ACTIVE'";
		try {
			
			
			
		
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1,b2);
			
			 rs=ps.executeQuery();
			
			 if(!rs.next()){
				
				 return null;
			 }
			 else
			 {
				 //fetching the details from resultset into account object
				Account a=new Account();
				a.setCustomerId(rs.getString(1));
				a.setAccountId(rs.getInt(2));
				a.setAccountType(rs.getString(3));
				a.setMessage(rs.getString(4));				
				a.setStatus(rs.getString(5));
				a.setLastTransaction(rs.getTimestamp(6));
				a.setBalance(rs.getDouble(7));
				//adding into arraylist
			list.add(a);	
			 }
			
			
			
			
			
	  }
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//returning arrayList
		DbTransaction.closeConnection(con);
		return list;

}

	public int deleteAccountDao(int b) {
		int a=0;
	
		DbTransaction DbTransaction=new DbTransaction();
		//Get connection object from DbTransaction object

		Connection con=DbTransaction.getConnection();
		//updating status to inactive in database
		String sql="update ACCOUNT_STATUS set STATUS='INACTIVE' where ACCOUNT_ID=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,b);
			a=ps.executeUpdate();
			
		
	}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//returns 1 if the execution is successfully
		DbTransaction.closeConnection(con);
		return a;
	}

	public String extractCustomerDao(int r) {
		// TODO Auto-generated method stub
		String a=null;
		DbTransaction DbTransaction=new DbTransaction();
		//Get connection object from DbTransaction object

		Connection con=DbTransaction.getConnection();
		//extracting the customer id by giving ssn_id
		String sql="select CUST_ID FROM CUSTOMER_STATUS where SSN_Id=? and Status='ACTIVE'";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,r);
			//ps.setString(2,"ACTIVE");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				//storing in a variable
				a=rs.getString(1);
			}
		
	}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbTransaction.closeConnection(con);
	return a;
}
	
	public String validateCustomerDao(String i){
		String a=null;
		DbTransaction DbTransaction=new DbTransaction();
		//Get connection object from DbTransaction object

		Connection con=DbTransaction.getConnection();
		//updating status to inactive in database
		try {
			PreparedStatement ps=con.prepareStatement("select status from customer_status where cust_id=?");
			
			ps.setString(1, i);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				 a=rs.getString(1);
			
			}
			
			
			
			
		}
		
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbTransaction.closeConnection(con);
		return a;
	}
}

