package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.bean.Transaction;
import com.util.DbTransaction;





public class TransactionDAO {
	public int getAccountDetailsFromDataBase(int accountId){
		Connection con=null;
		PreparedStatement pst = null;
		try {
			con=DbTransaction.getConnection();
			pst = con.prepareStatement("Select ACCOUNT_ID from ACCOUNT_STATUS where ACCOUNT_ID=? and status='ACTIVE'");
			pst.setInt(1, accountId);
			ResultSet rs = pst.executeQuery();
			if(!rs.next()){
				
				return 0;
			}
			else{
				
				 do{
					 accountId=rs.getInt(1);
				
				}while (rs.next());
				 return accountId;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbTransaction.closeConnection(con);
		}
		return 0;
		
	}
	public int getTotalNumberTransactionFromDB(int accId,Timestamp startTS,Timestamp endTS){
PreparedStatement ps;
		
		try {
			ps = DbTransaction.getConnection().prepareStatement("select count(*) from TRANSACTION where (ACCOUNT_ID=? or TARGET_ACC_ID=?) and TRANSACTION between ? and ?");
			ps.setInt(1, accId);
			ps.setInt(2, accId);
			ps.setTimestamp(3, startTS);
			ps.setTimestamp(4, endTS);
			ResultSet rs=ps.executeQuery();
			rs.next();
			return rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}//
	public int getTotalNumberTransactionFromDB(int accId,int noOfTransaction){
		PreparedStatement ps;
		
		try {
			ps = DbTransaction.getConnection().prepareStatement("SELECT count(*) FROM TRANSACTION where ACCOUNT_ID=?");
			ps.setInt(1, accId);
			
			ResultSet rs=ps.executeQuery();
			rs.next();
			
			return rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
	
	
	
	public ArrayList<Transaction> getAllTransactionFromDB(int accId,Timestamp startTS,Timestamp endTS,int offset){
		
		ArrayList<Transaction> allTransaction=new ArrayList<Transaction>();
		PreparedStatement ps;
		try {
			// where TRANSACTION >? and TRANSACTION <?
			//ps = DbTransaction.getConnection().prepareStatement("select * from TRANSACTION where ACCOUNT_ID=? and TRANSACTION between ? and ? limit 10 offset ?");// where ACCOUNT_ID=? and TRANSACTION<? and TRANSACTION >?
			ps = DbTransaction.getConnection().prepareStatement("select * from " +
					"(select trxn_id, account_id, trxn_type, amount, target_acc_id, transaction,rownum as rnum " +
					"from TRANSACTION where " +
					"(ACCOUNT_ID=? or TARGET_ACC_ID=?) and TRANSACTION between ? and ? and rownum<=?)" +
					" where rnum>?");// where ACCOUNT_ID=? and TRANSACTION<? and TRANSACTION >?
			
			ps.setInt(1, accId);
			ps.setInt(2, accId);
			ps.setTimestamp(3, startTS);
			ps.setTimestamp(4, endTS);
			ps.setInt(5, offset+10);
			ps.setInt(6, offset);
			
			ResultSet rs=ps.executeQuery();
			if(!rs.next()){
				//return null;
			}
			else{
				do{
					Transaction transactionObject=new Transaction();
					
					transactionObject.setTransactionId(rs.getString("TRXN_ID"));
					transactionObject.setAccountId(rs.getInt("ACCOUNT_ID"));
					transactionObject.setTransactionType(rs.getString("TRXN_TYPE"));
					transactionObject.setAmount(rs.getDouble("AMOUNT"));
					transactionObject.setTargetAccountId(rs.getInt("TARGET_ACC_ID"));
					transactionObject.setTransactionDate(rs.getTimestamp("TRANSACTION"));
					allTransaction.add(transactionObject);
					
				}while(rs.next());
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allTransaction;
	}
	
	
	public ArrayList<Transaction> getAllTransactionFromDB(int accId,int noOfTransaction,int offset){
		ArrayList<Transaction> allTransaction=new ArrayList<Transaction>();
		PreparedStatement ps;
		try {
			int numberToAdd=(offset+10<=noOfTransaction)?10:(noOfTransaction-offset);
			//ps = DbTransaction.getConnection().prepareStatement("select * from (SELECT * FROM TRANSACTION where ACCOUNT_ID=? order by TRANSACTION desc) where rownum<=?");
			ps = DbTransaction.getConnection().prepareStatement("select * from" +
					"(select trxn_id, account_id, trxn_type, amount, target_acc_id, transaction,rownum as rnum from " +
					"(SELECT trxn_id, account_id, trxn_type, amount, target_acc_id, transaction FROM " +
					"TRANSACTION where (ACCOUNT_ID=? or TARGET_ACC_ID=?) order by TRANSACTION desc ) where rownum<=?) where rnum>?");

			ps.setInt(1, accId);
			ps.setInt(2, accId);
			ps.setInt(3, offset+numberToAdd);
			ps.setInt(4, offset);
			ResultSet rs=ps.executeQuery();
			if(!rs.next()){
				//return null;
			}
			else{
				do{
					Transaction transactionObject=new Transaction();
					
					transactionObject.setTransactionId(rs.getString("TRXN_ID"));
					transactionObject.setAccountId(rs.getInt("ACCOUNT_ID"));
					transactionObject.setTransactionType(rs.getString("TRXN_TYPE"));
					transactionObject.setAmount(rs.getDouble("AMOUNT"));
					transactionObject.setTargetAccountId(rs.getInt("TARGET_ACC_ID"));
					transactionObject.setTransactionDate(rs.getTimestamp("TRANSACTION"));
					allTransaction.add(transactionObject);
					
				}while(rs.next());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allTransaction;
		
	}
}
