package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Comparator;
import java.util.TreeSet;

import com.bean.Customer;
import com.util.DbTransaction;

public class CustomerStatusDAO {
	public TreeSet<Customer> viewAllCustomer(){
		Connection con=null;
		TreeSet<Customer> tree=new TreeSet<Customer>(new MyComp());
		PreparedStatement pst = null;
		try {
			con=DbTransaction.getConnection();
			pst = con.prepareStatement("Select * from CUSTOMER_STATUS");
			ResultSet rs = pst.executeQuery();
			if(!rs.next()){
				//return null;
			}
			else{

				do{
					Customer c = new Customer();
					c.setCustomerId(rs.getString(1));
					c.setCustomerSSNId(rs.getInt(2));
					c.setCustomerName(rs.getString(3));
					c.setAge(rs.getInt(4));
					c.setAddress(rs.getString(5));
					c.setCity(rs.getString(6));
					c.setState(rs.getString(7));
					c.setMessage(rs.getString(8));
					c.setStatus(rs.getString(9));
					c.setLastUpdate(rs.getTimestamp(10));

					tree.add(c);
				}while (rs.next());
			}
			return tree;


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbTransaction.closeConnection(con);
		}
		return tree;

	}

	class MyComp implements Comparator<Customer>{

		@Override
		public int compare(Customer c1, Customer c2) {
			return c1.getCustomerId().compareTo(c2.getCustomerId());
		}

	}


	public Customer viewCustomer(String id){
		/*ResultSet rs=null;
		PreparedStatement pst=null;*/
		Connection con=null;
		Customer c = new Customer();
		//System.out.println("id="+id);
		try {
			con=DbTransaction.getConnection();
			PreparedStatement pst = con.prepareStatement("Select * from CUSTOMER_STATUS where CUST_ID=?");
			pst.setString(1,id);

			ResultSet rs = pst.executeQuery();
			if(!rs.next()){
				//need to write
			}else{

				do{
					//System.out.println(rs.getString(1));
					c.setCustomerId(rs.getString(1));
					c.setCustomerSSNId(rs.getInt(2));
					c.setCustomerName(rs.getString(3));
					c.setAge(rs.getInt(4));
					c.setAddress(rs.getString(5));
					c.setCity(rs.getString(6));
					c.setState(rs.getString(7));
					c.setMessage(rs.getString(8));
					c.setStatus(rs.getString(9));
					c.setLastUpdate(rs.getTimestamp(10));
				}while (rs.next());
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbTransaction.closeConnection(con);
		}
		/*finally{
				if(rs!=null)
					try {
						rs.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						}

				if(pst!=null)
				try {
						pst.close();
					}
				catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/
		//System.out.println(c.getAddress());
		return c;			
	}

}


