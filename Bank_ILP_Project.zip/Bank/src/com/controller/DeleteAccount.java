package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Account;
import com.service.DeleteAccountService;

@WebServlet("/DeleteAccount")
public class DeleteAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DeleteAccount() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String a = request.getParameter("accountid");
		int b = Integer.parseInt(a);
		DeleteAccountService c = new DeleteAccountService();
		int i = c.deleteAccount(b);
		if (i == 1) {
			request.setAttribute("message", "Account successfully deleted");
			RequestDispatcher rd = request
					.getRequestDispatcher("Executive/Success.jsp");
			rd.forward(request, response);
		} else {
			request.setAttribute("message", "Account not deleted");
			RequestDispatcher rd = request
					.getRequestDispatcher("Executive/Failed.jsp");
			rd.forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {

			String ssnid = request.getParameter("SSN_Id");

			String id = request.getParameter("Customer_Id");

			if (ssnid == null) {
				DeleteAccountService b = new DeleteAccountService();
				String status = b.validateCustomer(id);
				System.out.println(status);
				if(status==null) {
					request.setAttribute("message", "Customer not found");
					RequestDispatcher rd = request
							.getRequestDispatcher("Executive/Failed.jsp");
					rd.forward(request, response);
				}
				if (status.equalsIgnoreCase("ACTIVE")) {
					ArrayList<Account> a = b.viewAccounts(id);

					if (a == null) {
						request.setAttribute("message", "Account not found");
						RequestDispatcher rd = request
								.getRequestDispatcher("Executive/Failed.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("account", a);
						RequestDispatcher rd = request
								.getRequestDispatcher("Executive/DeleteAccount.jsp");
						rd.forward(request, response);
					}
				}
				
			
			}
			if (!ssnid.isEmpty()) {

				int r = Integer.parseInt(ssnid);

				DeleteAccountService z = new DeleteAccountService();
				String t = z.extractCustomer(r);

				if (t == null) {
					request.setAttribute("message", "Customer not found");
					RequestDispatcher rd = request
							.getRequestDispatcher("Executive/Failed.jsp");
					rd.forward(request, response);
				} else {

					ArrayList<Account> p = z.viewAccounts(t);
					if (p == null) {
						request.setAttribute("message", "Account not found");
						RequestDispatcher rd = request
								.getRequestDispatcher("Executive/Failed.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("account", p);
						request.getRequestDispatcher(
								"Executive/DeleteAccount.jsp").forward(request,
								response);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
