package com.controller;

import java.io.IOException;
import java.util.TreeSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Account;
import com.service.AccountStatusService;



/**
 * Servlet implementation class ViewAccountStatus
 */
@WebServlet("/ViewAccountStatusController")
public class ViewAccountStatusController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewAccountStatusController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		TreeSet<Account> allAccount=AccountStatusService.SearchAllAccount();
		HttpSession session=request.getSession();
		/*for(Account acc:allAccount){
			System.out.println(acc.getAccountId());
		}*/
		session.setAttribute("Account_details",allAccount);
		
		
		
		
		response.sendRedirect("Executive/StatusAccount.jsp?pageId=0");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
