package com.controller;

import java.io.IOException;
import java.security.AllPermission;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Transaction;
import com.service.TransactionService;




/**
 * Servlet implementation class TransactionController
 */
@WebServlet("/TransactionController")
public class TransactionController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TransactionController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getParameter("action").equalsIgnoreCase("check")){
			int accountId=Integer.parseInt(request.getParameter("acc_id"));
			int accId=TransactionService.getAccountDetails(accountId);
			//System.out.println("ser"+accId);

			if(accId==0)
				request.setAttribute("AccountExist", null);
			else
				request.setAttribute("AccountExist", accId);
			request.setAttribute("afterVerified", accId);
			request.getRequestDispatcher("Cashier/Statement.jsp").forward(request, response);
		}
		else{


			ArrayList<Transaction> allTransaction=new ArrayList<Transaction>();
			System.out.println(request.getParameter("NoOfTransac"));
			int totalTrunsuction;
			int accId=Integer.parseInt(request.getParameter("hidden_accId"));
			int pageId=Integer.parseInt(request.getParameter("pageId"));
			if(request.getParameter("NoOfTransac")!=null){
				int noOfTransaction=Integer.parseInt(request.getParameter("NoOfTransac"));

				//db call
				allTransaction=TransactionService.getAllTransaction(accId,noOfTransaction,pageId*10);
				totalTrunsuction=TransactionService.getTotalNumberTransaction(accId,noOfTransaction);
				if(totalTrunsuction>noOfTransaction)
					totalTrunsuction=noOfTransaction;
				
				/*request.setAttribute("startDate",null);
				request.setAttribute("endDate",null);*/
				request.setAttribute("NoOfTransac",noOfTransaction);
			}
			else{
				
				String sD=request.getParameter("StartDate");
				String eD=request.getParameter("EndDate");
				Date startDate=Date.valueOf(sD);
				Date endDate=Date.valueOf(eD);
				Timestamp startTS=new Timestamp(startDate.getTime());
				Timestamp endTS=new Timestamp(endDate.getTime());
				allTransaction=TransactionService.getAllTransaction(accId,startTS, endTS,pageId*10);
				totalTrunsuction=TransactionService.getTotalNumberTransaction(accId,startTS,endTS);
				
				
				request.setAttribute("startDate",sD);
				request.setAttribute("endDate",eD);
				//request.setAttribute("NoOfTransac",null);
			}
			request.setAttribute("resultShow", 1);
			request.setAttribute("pageId",pageId);
			/////////////////
			System.out.println(totalTrunsuction);
			if((pageId*10)+10>totalTrunsuction)
			request.setAttribute("isNextPage",null);
			else request.setAttribute("isNextPage",totalTrunsuction);

			request.setAttribute("allTransaction",allTransaction);
			request.setAttribute("accId",accId);
			request.getRequestDispatcher("Cashier/Statement.jsp").forward(request, response);


		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub


	}

}
