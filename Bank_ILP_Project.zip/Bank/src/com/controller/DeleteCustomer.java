package com.controller;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Customer;
import com.service.DeleteCustomerService;


@WebServlet("/DeleteCustomer")
public class DeleteCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteCustomer() {
        super();
    }
protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException
{
	try {
		String id=req.getParameter("id");
		System.out.println(id);
		DeleteCustomerService b=new DeleteCustomerService();
		b.accountdelete(id);

		int i=b.deleteCustomer(id);
		
		if(i==1)
		{
			b.updateTime(id);
			req.setAttribute("message", "Customer deleted successfully");
			RequestDispatcher rd=req.getRequestDispatcher("Executive/Success.jsp");
			rd.forward(req, res);
;		}
		else
		{
			req.setAttribute("message", "Customer not found");
			RequestDispatcher rd=req.getRequestDispatcher("Executive/Failed.jsp");
			rd.forward(req, res);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}
	
	

	protected void doPost(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException 
	{
	
		String id=req.getParameter("Customer_Id");
		
		
		DeleteCustomerService b=new DeleteCustomerService();
		String a=b.validateCustomer(id);
		if(a.equalsIgnoreCase("ACTIVE"))
		{
		Customer c=b.viewCustomer(id);
		if(c==null)
		{
			req.setAttribute("message", "Customer not found");
			RequestDispatcher rd=req.getRequestDispatcher("Executive/Failed.jsp");
			rd.forward(req,response);
		}
		else
		{
			req.setAttribute("customer",c);
			RequestDispatcher rd=req.getRequestDispatcher("Executive/DeleteCustomer.jsp");
			rd.forward(req,response);
		}
		}
		else
		{
			req.setAttribute("message", "Customer not found");
			RequestDispatcher rd=req.getRequestDispatcher("Executive/Failed.jsp");
			rd.forward(req,response);
		}
		
		
	}

}
