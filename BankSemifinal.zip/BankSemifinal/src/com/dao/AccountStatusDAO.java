package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Comparator;
import java.util.TreeSet;

import com.bean.Account;
import com.util.DbTransaction;


public class AccountStatusDAO {

	
	public TreeSet<Account> viewAllAccount(){
		
		TreeSet<Account> tree=new TreeSet<Account>(new MyComp());
		
		PreparedStatement pst = null;
		try {
			pst = DbTransaction.getConnection().prepareStatement("Select * from ACCOUNT_STATUS");
			ResultSet rs = pst.executeQuery();
			if(!rs.next()){
				//empty
			}
			else{
				
				 do{
					Account acc = new Account();
					 acc.setAccountId(rs.getInt(2));
					 acc.setCustomerId(rs.getString(1));
					 acc.setAccountType(rs.getString("ACCOUNT_TYPE"));
					 acc.setBalance(rs.getDouble("BALANCE"));
					 acc.setMessage(rs.getString("MESSAGE"));
					 acc.setStatus(rs.getString("STATUS"));
					 acc.setLastTransaction(rs.getTimestamp("LAST_TRANSACTION"));
					 
					
					tree.add(acc);
				}while (rs.next());
			}
			return tree;
				
			
	} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tree;

	}
		
	class MyComp implements Comparator<Account>{
			 
		@Override
		   public int compare(Account c1, Account c2) {
		        return c1.getAccountId()-c2.getAccountId();
		    }
		
		}
		
		
	

}
		
	


