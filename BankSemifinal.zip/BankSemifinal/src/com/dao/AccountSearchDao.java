package com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import com.util.DbTransaction;

public class AccountSearchDao {

	static Connection con=null;	
	static PreparedStatement ps=null;
	static ResultSet rs=null;
	ArrayList<Object> data=new ArrayList<Object>();/*used to pass retrieved data*/
	//US0010->searching accountId or customerId for getting CUST_ID,ACCOUNT_ID,ACCOUNT_TYPE,BALANCE 
	    public  ArrayList<Object> search_AccountById(String id,int flag,String type){
		       System.out.println("HERE I COME TO RETRIEVE DATA");
		       con=DbTransaction.getConnection();
		       String query=" ";
		       //retrieving data by using customer_id
		       if(flag==1)
		              query="select CUST_ID,ACCOUNT_ID,ACCOUNT_TYPE,BALANCE from ACCOUNT_STATUS where CUST_ID=? and ACCOUNT_TYPE=?";
		               try {
				       ps=con.prepareStatement(query);
				       ps.setString(1,id);
				       ps.setString(2,type);
						rs=ps.executeQuery();
						if(rs.next()){
							System.out.println(rs.getString(1));
						data.add(rs.getString(1));
						data.add(rs.getInt(2));
						data.add(rs.getString(3));
						data.add(rs.getDouble(4));
		                }
				       
			    } catch (SQLException e) {
				     e.printStackTrace();
			      }
		    //retrieving data by using Account_id
		      if(flag==2){
			          query="select CUST_ID,ACCOUNT_ID,ACCOUNT_TYPE,BALANCE from ACCOUNT_STATUS where ACCOUNT_ID=? and ACCOUNT_TYPE=?";
					  try {
							ps=con.prepareStatement(query);
							ps.setInt(1,Integer.parseInt(id));
							ps.setString(2,type);
                 		    rs=ps.executeQuery();
				               if(rs.next()){
					               System.out.println(rs.getString(1));
			         	           data.add(rs.getString(1));
				                   data.add(rs.getInt(2));
				                   data.add(rs.getString(3));
							       data.add(rs.getDouble(4));
                               }
                       } catch (SQLException |NumberFormatException e){
               				e.printStackTrace();
			             }
		      }
		    System.out.println("Ready steady po");
		    DbTransaction.closeConnection(con);
		    return data;// returning arraylist with data
	}
	
	
	
	
	public String[] search_AccountById(int flag,String id){
           String[] temp=new String[2];		
	       con=DbTransaction.getConnection();
	       String query=" ";
	       //retrieving data by using customer_id
	       if(flag==1){
	              query="select ACCOUNT_TYPE,STATUS from ACCOUNT_STATUS where CUST_ID=?";
	              try {
			           ps=con.prepareStatement(query);
			           ps.setString(1,id);
	     	           rs=ps.executeQuery();
	    	           if(rs==null)
	     		             return null;
	    	           int i=0;
		               if(rs.next()){
		            	       if(rs.getString(2).equals("ACTIVE"))
                                   temp[i++]=rs.getString(1);
		            	}
                       if(rs.next()){
	            	       if(rs.getString(2).equals("ACTIVE"))	            	    	    
                    	   temp[i]=rs.getString(1);
                       }
    	          } catch (SQLException e) {
		                      	e.printStackTrace();
		             }
	       }	    
	    //retrieving data by using Account_id
	    if(flag==2){
		             query="select ACCOUNT_TYPE,STATUS from ACCOUNT_STATUS where ACCOUNT_ID=?";
				     try {
						    ps=con.prepareStatement(query);
						    ps.setInt(1,Integer.parseInt(id));
					     	rs=ps.executeQuery();
					     	if(rs==null){
					     		return null;
					     	}
					     	int i=0;
						    if(rs.next()){
						    	if(rs.getString(2).equals("ACTIVE"))
						    	temp[i++]=rs.getString(1);
						    }
			  			    if(rs.next()){
			  			    	if(rs.getString(2).equals("ACTIVE"))
				                       temp[i]=rs.getString(1);
			  			    }
					   } catch (NumberFormatException |SQLException e) {
						e.printStackTrace();
	                     }
	    }
	    DbTransaction.closeConnection(con);
    	return temp;
	}

}

 
