package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;

import com.bean.Customer;
import com.util.DbTransaction;

public class DeleteCustomerDao {
	
	
	public Customer viewCustomerdao(String id)
	{
		Customer c=new Customer();
		
		Connection con=DbTransaction.getConnection();
		String sql="select * from CUSTOMER_STATUS where CUST_ID=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				c.setCustomerSSNId(rs.getInt(2));
				c.setCustomerId(rs.getString(1));
				c.setCustomerName(rs.getString(3));
				c.setAge(rs.getInt(4));
				c.setAddress(rs.getString(5));
				
			}
			else
			
			{
				DbTransaction.closeConnection(con);
				return null;
				
			}
		}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbTransaction.closeConnection(con);
	return c;
		}

	public int deleteCustomerdao(String id) {
		int i=0;
		
		Connection con=DbTransaction.getConnection();
		String sql="update CUSTOMER_STATUS set status=? where  CUST_ID=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,"INACTIVE");
			ps.setString(2,id);
			i=ps.executeUpdate();
			
		
	
	}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbTransaction.closeConnection(con);
	return i;

}

	public int accountdeletedao(String id) 
	{
		
		int j=0;
		
		Connection con=DbTransaction.getConnection();
		String sql="update Account_STATUS set status=? where  CUST_ID=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,"INACTIVE");
			ps.setString(2,id);
			j=ps.executeUpdate();
			
		
	
	}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbTransaction.closeConnection(con);
	return j;

	}

	public void updateTimeDao(String id) 
	{
		int k=0;
		
		Connection con=DbTransaction.getConnection();
		String sql="update CUSTOMER_STATUS set LAST_UPDATE=CURRENT_TIMESTAMP where  CUST_ID=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,id);
			k=ps.executeUpdate();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbTransaction.closeConnection(con);

	}

	public String validateCustomerDao(String id) {
		// TODO Auto-generated method stub
		String a=null;
		
		Connection con=DbTransaction.getConnection();
		String sql="select status from CUSTOMER_STATUS where CUST_ID=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,id);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				 a=rs.getString(1);
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return a;
	}
}