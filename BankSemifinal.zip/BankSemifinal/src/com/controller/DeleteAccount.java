package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Account;
import com.service.DeleteAccountService;


@WebServlet("/DeleteAccount")
public class DeleteAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteAccount() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String a=request.getParameter("accountid");
		int b=Integer.parseInt(a);
		DeleteAccountService c=new DeleteAccountService();
		int i=c.deleteAccount(b);
		if(i==1)
		{
			RequestDispatcher rd=request.getRequestDispatcher("success.jsp");
			rd.forward(request,response);
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
			rd.forward(request,response);
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		try {

			String ssnid=request.getParameter("SSN_Id");

			String id=request.getParameter("Customer_Id");
			
			
			
			
			if(ssnid.isEmpty())
			{
			DeleteAccountService b=new DeleteAccountService();
			String status=b.validateCustomer(id);
			if(status.equalsIgnoreCase("ACTIVE"))
			{
			 ArrayList<Account> a=b.viewAccounts(id);
			 
			
			 if(a==null){
				 RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
					rd.forward(request,response);
			 }
			 else{
			 request.setAttribute("account",a);
			 RequestDispatcher rd=request.getRequestDispatcher("Executive/DeleteAccount.jsp");
			 rd.forward(request,response);
			}
			}
			else
			{
				 RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
					rd.forward(request,response);
			}
			}
			if(!ssnid.isEmpty())
			{
				
				int r=Integer.parseInt(ssnid);
				
				DeleteAccountService z=new DeleteAccountService();
				String t=z.extractCustomer(r);
				
				if(t==null)
				{
					
					RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
					rd.forward(request,response);
				}
				else
				{
				
				 ArrayList<Account> p=z.viewAccounts(t);
				 if(p==null)
				 {
					 RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
						rd.forward(request,response);
				 }
				 else
				 {
				 request.setAttribute("account",p);
				 request.getRequestDispatcher("Executive/DeleteAccount.jsp").forward(request,response);
				}
				}
			}
					}
		catch(Exception e)
		{
			e.printStackTrace();
		}
					 
			
			
	}

	}


