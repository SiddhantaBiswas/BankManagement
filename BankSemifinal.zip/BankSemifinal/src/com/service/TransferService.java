package com.service;

import com.bean.Account;
import com.dao.TransferDAO;



public class TransferService {
	public static Account[] checkCustomer(String customerId){
		TransferDAO td=new TransferDAO();
		Account[] acc=new Account[2];
		acc = td.check(customerId);


		return acc;
	}


	public static boolean transferAmount(int sourceAccId,int targetAccId,int balance){
		System.out.println("bank");
		return new TransferDAO().transferAmount(sourceAccId, targetAccId,balance);
	}
}
