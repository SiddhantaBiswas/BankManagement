package com.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.Account;
import com.bean.Customer;
import com.dao.DeleteAccountDao;

public class DeleteAccountService {
	
	public ArrayList<Account> viewAccounts(String b2)
	{
		DeleteAccountDao b=new DeleteAccountDao();
		ArrayList<Account> a= b.viewAccountsDao(b2);
		
		return a;
		
	}

	public int deleteAccount(int b) {
		// TODO Auto-generated method stub
		DeleteAccountDao c=new DeleteAccountDao();
        int a=c.deleteAccountDao(b);
        return a;
	}

	public String extractCustomer(int r) {
		// TODO Auto-generated method stub
		DeleteAccountDao d=new DeleteAccountDao();
		String a=d.extractCustomerDao(r);
		if(a!=null)
		{
		return a;
		}else
		{
			return null;
		}
	}
	public String validateCustomer(String id)
	{
		DeleteAccountDao a=new DeleteAccountDao();
		String b=a.validateCustomerDao(id);
		return b;
		
	}


}
