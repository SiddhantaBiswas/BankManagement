package com.service;

import java.util.TreeSet;

import com.bean.Customer;
import com.dao.CustomerStatusDAO;





public class CustomerStatusService {

	public static TreeSet<Customer> SearchAllCustomer(){
		CustomerStatusDAO dao=new CustomerStatusDAO();
		TreeSet<Customer> tree=new TreeSet<Customer>();

		tree=dao.viewAllCustomer();
		return tree;
	}
	public static Customer viewCustomer(String id){
		CustomerStatusDAO dao=new CustomerStatusDAO();
		Customer c=new Customer();
		c=dao.viewCustomer(id);
		return c;
	}



}