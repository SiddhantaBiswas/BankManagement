package com.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.bean.Transaction;
import com.dao.TransactionDAO;



public class TransactionService {
	public static int getAccountDetails(int accountId){
		return new TransactionDAO().getAccountDetailsFromDataBase(accountId);
	}
	public static ArrayList<Transaction> getAllTransaction(int accId,Timestamp startTS,Timestamp endTS,int offset){
		return new TransactionDAO().getAllTransactionFromDB(accId,startTS, endTS,offset);
		
	}
	public static ArrayList<Transaction> getAllTransaction(int accId,int noOfTransaction,int offset){
		return new TransactionDAO().getAllTransactionFromDB(accId,noOfTransaction,offset);
		
	}
	public static int getTotalNumberTransaction(int accId,int noOfTransaction){
		return new TransactionDAO().getTotalNumberTransactionFromDB(accId,noOfTransaction);
		
	}
	public static int getTotalNumberTransaction(int accId,Timestamp startTS,Timestamp endTS){
		return new TransactionDAO().getTotalNumberTransactionFromDB(accId,startTS, endTS);
		
	}
}

