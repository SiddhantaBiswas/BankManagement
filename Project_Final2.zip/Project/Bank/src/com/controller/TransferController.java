package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Account;
import com.service.TransferService;



/**
 * Servlet implementation class TransferController
 */
@WebServlet("/TransferController")
public class TransferController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TransferController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String cust_id=request.getParameter("cust_id");
		Account[] accountOfCustomer=TransferService.checkCustomer(cust_id);
		/*if(accountOfCustomer!=null){
			for(Account acc:accountOfCustomer){
				System.out.println(acc.getAccountId());
			}
		}
		else{
			System.out.println("no acc");
		}*/
		HttpSession session=request.getSession();
		session.setAttribute("accountOfCustomer", accountOfCustomer);
		session.setAttribute("afterCheck",1);
		response.sendRedirect("Cashier/Transfer.jsp") ;
		//call service

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int targetAccId;
		int accountId1=Integer.parseInt(request.getParameter("AccountId1"));
		int accountId2=Integer.parseInt(request.getParameter("AccountId2"));
		int sourceAccountId=Integer.parseInt(request.getParameter("sourceAccountName"));
		int balance=Integer.parseInt(request.getParameter("transferAmountName"));
		if(sourceAccountId==accountId1) targetAccId=accountId2;
		else targetAccId=accountId1;
		//System.out.println(accountId1+" 2:"+accountId2+" s:"+sourceAccountId+" t:"+targetAccId);
		if(TransferService.transferAmount(sourceAccountId, targetAccId,balance)){
			//to success
			request.setAttribute("message", "Funds transferred successfully");
			request.getRequestDispatcher("Cashier/Success.jsp").forward(request, response);
		}
		else{
			//to error
			request.setAttribute("message", "Funds transfer failed. Please try again later.");
			request.getRequestDispatcher("Cashier/Failed.jsp").forward(request, response);
		}

	}

}
