package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Account;
import com.service.DepositWithdrawService;

@WebServlet("/WithdrawController")

public class WithdrawController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public WithdrawController() {
		super();

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 

	{
		//value fetch			
		    Account acc = new Account();
			int aid =(Integer.parseInt(request.getParameter("account_id")));
			System.out.println(aid);
		
			double amount=0;
		    request.setAttribute("account_id", aid);
			
		    
	/*=====================Calling service to fetch account details before any transaction============ */
		    
		    System.out.println("fetch------------"+request.getParameter("action"));
		    if (request.getParameter("action").equals("fetch"))
		    {
			try{
				acc = DepositWithdrawService.fetchAccountData(aid);
				if(acc.getBalance() != -1)
				{ 
					request.setAttribute("account", acc);
					RequestDispatcher rd = request.getRequestDispatcher("Cashier/Withdraw.jsp");
					rd.forward(request, response);
				}
				else 
				{   
					request.setAttribute("message","Account does not exist");
					request.getRequestDispatcher("Cashier/Failed.jsp").forward(request, response);
				}
				
			}

			catch(ServletException | IOException e)
			{
				e.printStackTrace();
			}
		    }
			
			/*=====================Calling service to withdraw money============ */  
		    
		    
		    System.out.println("withdraw------------"+request.getParameter("action"));
		    if (request.getParameter("action").equals("withdraw"))
			try
			{
				amount = Double.parseDouble(request.getParameter("amount"));
				aid = Integer.parseInt(request.getParameter("account_id"));
				request.setAttribute("amount", amount);
				acc = DepositWithdrawService.withdraw(aid, amount);
				if(acc.getBalance() == -1){
					request.setAttribute("message","Account does not have enough balance");
					request.getRequestDispatcher("Cashier/Failed.jsp").forward(request, response);
				} else {
					request.setAttribute("message","Amount withdrawal successful");
					request.getRequestDispatcher("Cashier/Success.jsp").forward(request, response);
				}
					
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}



		}
	
}
