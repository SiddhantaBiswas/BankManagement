package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.Account;
import com.util.DbTransaction;



public class TransferDAO {
	public Account[] check(String id){
		Account[] result=new Account[2];
		Connection conn=null;
		PreparedStatement pst;
		ResultSet rs;
		ArrayList<Account> a=new ArrayList<Account>();
		try {
			//System.out.println("---------------------------------------------------");
			conn = DbTransaction.getConnection();
			//System.out.println("CONNNNNNNNNNNNNNNNNNNNNNNNNN");
			pst=conn.prepareStatement("select count(*) from CUSTOMER_STATUS c,ACCOUNT_STATUS a where c.CUST_ID=a.CUST_ID and c.CUST_ID=? AND a.STATUS='ACTIVE' and c.STATUS='ACTIVE'");
			pst.setString(1,id);
			rs = pst.executeQuery();
			//System.out.println("111111111111111111111111111111111111111111111111111111111111111111111");
			rs.next();
			if (rs.getInt(1) == 2) {

				/*if(DbTransaction.getConnection()!=null)
							{DbTransaction.closeConnection();*/
				pst.close();
				rs.close();
				pst = conn
						.prepareStatement("select * from ACCOUNT_STATUS where CUST_ID=?");
				pst.setString(1,id);
				rs = pst.executeQuery();
				while(rs.next()){
					Account acc=new Account(); 
					acc.setCustomerId(rs.getString(1));
					acc.setAccountId(rs.getInt(2));
					acc.setAccountType(rs.getString(3));
					acc.setMessage(rs.getString(4));
					acc.setStatus(rs.getString(5));
					acc.setLastTransaction(rs.getTimestamp(6));
					acc.setBalance(rs.getInt(7));
					a.add(acc);
				}
				result=	a.toArray(result);

			} else if(rs.getInt(1) == 1){
				//System.out.println("ONLY ONE ACCOUNT EXISTS");
				return null;
			}
			else
			{
				return null;
			}


		}catch(SQLException sql){

			sql.printStackTrace();		
		}finally{
			/*if(conn!=null){
			DBTransaction.closeConnection();
			if(pst!=null)
				try {
					pst.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(rs!=null)
					try {
						rs.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			 */
			DbTransaction.closeConnection(conn);
		}
		return result;

	}




	public Boolean transferAmount(int sourceAccId,int targetAccId,int balance){
		PreparedStatement pst = null;
		Connection conn;

		//System.out.println(sourceAccId+" "+balance);
		conn = DbTransaction
				.getConnection();
		//System.out.println("CONNNNNNNNNNNNNNNNNNNNNNNNNN");
		try {
			pst=conn.prepareStatement("update ACCOUNT_STATUS set balance=CASE when account_id=? then balance-? when account_id=? then balance+? else balance end, LAST_TRANSACTION=CASE when account_id=? then CURRENT_TIMESTAMP when account_id=? then CURRENT_TIMESTAMP else LAST_TRANSACTION end");
			pst.setInt(1, sourceAccId);
			pst.setInt(2, balance);
			pst.setInt(3, targetAccId);
			pst.setInt(4, balance);
			pst.setInt(5, sourceAccId);
			pst.setInt(6, targetAccId);
			int editedRow=pst.executeUpdate();
			pst=conn.prepareStatement("insert into TRANSACTION values('TRXN'||LPAD(to_char(TRANSACTION_SEQ.nextval),'6','0'),?,'TRANSFER',?,?,CURRENT_TIMESTAMP)");
			pst.setInt(1, sourceAccId);
			pst.setInt(2, balance);
			pst.setInt(3, targetAccId);
			pst.executeUpdate();
			if(editedRow==0) return false;
			else return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
		//System.out.println("111111111111111111111111111111111111111111111111111111111111111111111");
	}







}

